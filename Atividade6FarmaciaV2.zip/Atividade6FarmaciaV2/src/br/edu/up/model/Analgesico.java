package br.edu.up.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.TableGenerator;

@Entity
@TableGenerator(
	name = "gerador_de_ip_analgesico",
	table = "sqlite_sequence",
	pkColumnName = "name",
	valueColumnName = "seq",
	pkColumnValue = "analgesico",
	initialValue = 1,
	allocationSize = 1
		
)
public class Analgesico {

	@Id
	@GeneratedValue (strategy = GenerationType.TABLE, generator = "gerador_de_ip_analgesico")
	private int id;
	private String nome;
	private double preco;
	
	
	//Construtor vazio
	public Analgesico() {
	}
	
	//Construtor que recebe nome e pre�o
	public Analgesico(String nome, double preco) {
		super();
		this.nome = nome;
		this.preco = preco;
	}
	
	//Construtor que recebe id, nome, pre�o
	public Analgesico(int id, String nome, double preco) {
		super();
		this.id = id;
		this.nome = nome;
		this.preco = preco;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}

}
