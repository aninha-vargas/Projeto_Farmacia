package br.edu.up.sistema;

import java.util.Date;
import java.util.List;
import java.util.Scanner;

import br.edu.up.dao.AnalgesicoDAO;
import br.edu.up.dao.AntiacidoDAO;
import br.edu.up.dao.AntibioticoDAO;
import br.edu.up.dao.ItemPedidoDAO;
import br.edu.up.dao.PedidoDAO;
import br.edu.up.model.Analgesico;
import br.edu.up.model.Antiacido;
import br.edu.up.model.Antibiotico;
import br.edu.up.model.ItemPedido;
import br.edu.up.model.Pedido;

public class Atendimento {
	
	public static void processar() {
		
		AntiacidoDAO daoAntiacido = new AntiacidoDAO();
		AnalgesicoDAO daoAnalgesico = new AnalgesicoDAO();
		AntibioticoDAO daoAntibiotico = new AntibioticoDAO();
		PedidoDAO daoPedido = new PedidoDAO();
		ItemPedidoDAO daoItensPedido = new ItemPedidoDAO();
		
		Pedido pedido = new Pedido();
		pedido.setDataPedido(new Date());
		daoPedido.salvar(pedido);
		
		Scanner leitor = new Scanner(System.in);
		
		
		
		int contador = 1;
		while (contador != 0 ){
			
			System.out.println("**********************************");
			System.out.println("QUAL MEDICAMENTO PESQUISAR");
			System.out.println();
			System.out.println("         1  -  Analgesico");
			System.out.println("         2  -  Antiacido");
			System.out.println("         3  -  Antibiotico");
			System.out.println();
			System.out.println("DIGITE SUA OP��O: ");
			int menu = leitor.nextInt();
			leitor.nextLine();
			System.out.println();
			
			if (menu==1) {
				
				List<Analgesico> listaag = daoAnalgesico.listar();	
				for (Analgesico ag : listaag) {
					System.out.println("Id: " + ag.getId() + " Analgesico: " + ag.getNome() + " Pre�o: " + ag.getPreco());
				}
				
				ItemPedido itemPedido = new ItemPedido();
				
				//Retorna o analg�sico selecionado (nome, preco)
				System.out.println();
				System.out.println("**********************************");
				System.out.println();
				System.out.println("ESCOLHA O ID DO MEDICAMENTO: ");
				int escolhaAnalg = leitor.nextInt();
				leitor.nextLine();
				
				Analgesico analgesicoSelecionado = daoAnalgesico.buscarPorId(escolhaAnalg);
				itemPedido.setNome(analgesicoSelecionado.getNome());
				itemPedido.setPreco(analgesicoSelecionado.getPreco());
				
						
				//quantidade dos itens (qtd)
				System.out.println("QUANTIDADE: ");
				int qtdAnalg = leitor.nextInt();
				leitor.nextLine();
				itemPedido.setQtd(qtdAnalg);
				
				itemPedido.setPedido(pedido);
				
				daoItensPedido.salvar(itemPedido);
				
				pedido.adicionarItemPedido(itemPedido);
				
									
			}else if (menu==2) {
				
				List<Antiacido> listaac = daoAntiacido.listar();	
				for (Antiacido ac : listaac) {
					System.out.println("Id: " + ac.getId() + " Antiacido: " + ac.getNome() + " Pre�o: " + ac.getPreco());
				}
				
				ItemPedido itemPedido = new ItemPedido();
				
				//Retorna o antiacido selecionado (nome, preco)
				System.out.println();
				System.out.println("**********************************");
				System.out.println();
				System.out.println("ESCOLHA O ID DO MEDICAMENTO: ");
				int escolhaAntia = leitor.nextInt();
				leitor.nextLine();
				
				Antiacido antiacidoSelecionado = daoAntiacido.buscarPorId(escolhaAntia);
				itemPedido.setNome(antiacidoSelecionado.getNome());
				itemPedido.setPreco(antiacidoSelecionado.getPreco());
				
						
				//quantidade dos itens (qtd)
				System.out.println("QUANTIDADE: ");
				int qtdAntia = leitor.nextInt();
				leitor.nextLine();
				itemPedido.setQtd(qtdAntia);
				
				itemPedido.setPedido(pedido);
				
				daoItensPedido.salvar(itemPedido);
				
				pedido.adicionarItemPedido(itemPedido);
				
			
			} else if (menu==3) {
				
				List<Antibiotico> listaab = daoAntibiotico.listar();	
				for (Antibiotico ab : listaab) {
					System.out.println("Id: " + ab.getId() + " Antibiotico: " + ab.getNome() + " Pre�o: " + ab.getPreco());
				}
				
				ItemPedido itemPedido = new ItemPedido();
				
				//Retorna o antibiotico selecionado (nome, preco)
				System.out.println();
				System.out.println("**********************************");
				System.out.println();
				System.out.println("ESCOLHA O ID DO MEDICAMENTO: ");
				int escolhaAntib = leitor.nextInt();
				leitor.nextLine();
				
				Antibiotico antibioticoSelecionado = daoAntibiotico.buscarPorId(escolhaAntib);
				itemPedido.setNome(antibioticoSelecionado.getNome());
				itemPedido.setPreco(antibioticoSelecionado.getPreco());
				
						
				//quantidade dos itens (qtd)
				System.out.println("QUANTIDADE: ");
				int qtdAntib = leitor.nextInt();
				leitor.nextLine();
				itemPedido.setQtd(qtdAntib);
				
				itemPedido.setPedido(pedido);
				
				daoItensPedido.salvar(itemPedido);
				
				pedido.adicionarItemPedido(itemPedido);
			}
			
			System.out.println();
			System.out.println();
			System.out.println("DESEJA INCLUIR MAIS MEDICAMENTOS? ");
			System.out.println("DIGITE: 1 - SIM OU 0 - N�O");
			contador = leitor.nextInt();
			leitor.nextLine();
			System.out.println();
			
		}
		
		daoPedido.salvar(pedido);
		System.out.println("**********************************");
		System.out.println();
		System.out.println("         PEDIDO NRO " + pedido.getId());
		System.out.println("       INCLU�DO COM SUCESSO");
		System.out.println();
		System.out.println("**********************************");
	
		leitor.close();
	}
}
