package br.edu.up.sistema;

import java.util.List;
import java.util.Scanner;

import br.edu.up.dao.AnalgesicoDAO;
import br.edu.up.dao.AntiacidoDAO;
import br.edu.up.dao.AntibioticoDAO;
import br.edu.up.model.Analgesico;
import br.edu.up.model.Antiacido;
import br.edu.up.model.Antibiotico;

public class Gestao {
	
	public static void processar() {
		
		Scanner leitor = new Scanner(System.in); 
		
		AntiacidoDAO daoAntiacido = new AntiacidoDAO();
		AnalgesicoDAO daoAnalgesico = new AnalgesicoDAO();
		AntibioticoDAO daoAntibiotico = new AntibioticoDAO();
		
		int contador = 1;
		while (contador != 0 ) {
			
			System.out.println();
		    System.out.println("QUANTO AOS MEDICAMENTOS, DESEJA: ");
		    System.out.println("   1  -  LISTAR");
			System.out.println("   2  -  INCLUIR");
			System.out.println("   3  -  ATUALIZAR");
			System.out.println("   4  -  EXCLUIR");
			System.out.println();
			System.out.println("DIGITE SUA OP��O: ");
			int opcaoAdm = leitor.nextInt();
			leitor.nextLine();
			System.out.println("****************************************************");
			
			if (opcaoAdm == 1) { //LISTAR
				 System.out.println();
				 System.out.println("QUAL MENU LISTAR? ");
				 System.out.println("   1  -  Analgesico");
				 System.out.println("   2  -  Antiacido");
				 System.out.println("   3  -  Antibiotico");
				 int opcaoListar = leitor.nextInt();
				 leitor.nextLine();
				 System.out.println("****************************************************");
				 System.out.println();
				 
				 
				 if (opcaoListar == 1) {//listarAnalgesicos();
				 	List<Analgesico> listaag = daoAnalgesico.listar();	
					for (Analgesico ag : listaag) {
						System.out.println("Id: " + ag.getId() + " Analgesico: " + ag.getNome() + " Pre�o: " + ag.getPreco());
					}
				 }
				 
				 	
				 if (opcaoListar == 2) {//listarAntiacidos();
					List<Antiacido> listaac = daoAntiacido.listar();	
					for (Antiacido ac : listaac) {
						System.out.println("Id: " + ac.getId() + " Antiacido: " + ac.getNome() + " Pre�o: " + ac.getPreco());
					}
				 }
							
					
				 if (opcaoListar == 3) {//listarAntibioticos();
					List<Antibiotico> listaab = daoAntibiotico.listar();	
					for (Antibiotico ab : listaab) {
						System.out.println("Id: " + ab.getId() + " Antibiotico: " + ab.getNome() + " Pre�o: " + ab.getPreco());
					}
				 }
				 
				 System.out.println("****************************************************");
				 System.out.println();
				 System.out.println("DESEJA RETORNAR A MANUTEN��O DOS MEDICAMENTOS? ");
				 System.out.println("DIGITE: 1-SIM OU 0-N�O ");
				 contador = leitor.nextInt();
				 leitor.nextLine();
				 System.out.println("****************************************************");
			
			}
			
			if (opcaoAdm == 2) { //INCLUIR
				 System.out.println("EM QUAL GRUPO INCLUIR? ");
				 System.out.println("   1  -  Analgesico");
				 System.out.println("   2  -  Antiacido");
				 System.out.println("   3  -  Antibiotico");
				 int opcaoIncluir = leitor.nextInt();
				 leitor.nextLine();
				 System.out.println("****************************************************");
				 System.out.println();
				 
				 if (opcaoIncluir == 1) {//Analgesico
					 Analgesico analgesico = new Analgesico();
					 System.out.println("Nome do rem�dio: ");
					 String nomeAnalg = leitor.nextLine();
					 analgesico.setNome(nomeAnalg);
					 System.out.println("Valor (centavos separar com virgula): ");
					 Double valorAnalg = leitor.nextDouble();
					 analgesico.setPreco(valorAnalg);
					 daoAnalgesico.salvar(analgesico);
					 System.out.println();
					 System.out.println("INCLU�DO COM SUCESSO");
				 }
				 
				 if (opcaoIncluir == 2) {//Antiacido
					 Antiacido antiacido = new Antiacido();
					 System.out.println("Nome do rem�dio: ");
					 String nomeAntiac = leitor.nextLine();
					 antiacido.setNome(nomeAntiac);
					 System.out.println("Valor (centavos separar com virgula): ");
					 Double valorAntiac = leitor.nextDouble();
					 antiacido.setPreco(valorAntiac);
					 daoAntiacido.salvar(antiacido);
					 System.out.println();
					 System.out.println("INCLU�DO COM SUCESSO");
				 }
				 
				 if (opcaoIncluir == 3) {//Antibiotico
					 Antibiotico antibiotico = new Antibiotico();
					 System.out.println("Nome do rem�dio: ");
					 String nomeAntib = leitor.nextLine();
					 antibiotico.setNome(nomeAntib);
					 System.out.println("Valor (centavos separar com virgula): ");
					 Double valorAntib = leitor.nextDouble();
					 antibiotico.setPreco(valorAntib);
					 daoAntibiotico.salvar(antibiotico);
					 System.out.println();
					 System.out.println("INCLU�DO COM SUCESSO");
				 }
				 
				 System.out.println("****************************************************");
				 System.out.println();
				 System.out.println("DESEJA RETORNAR A MANUTEN��O DOS MEDICAMENTOS? ");
				 System.out.println("DIGITE: 1-SIM OU 0-N�O ");
				 contador = leitor.nextInt();
				 leitor.nextLine();
				 System.out.println("****************************************************");
				 
			}
			
			if (opcaoAdm == 3) { //ATUALIZAR
				 System.out.println("EM QUAL GRUPO ATUALIZAR? ");
				 System.out.println("   1  -  Analgesico");
				 System.out.println("   2  -  Antiacido");
				 System.out.println("   3  -  Antibiotico");
				 int opcaoAtualizar = leitor.nextInt();
				 leitor.nextLine();
				 System.out.println("****************************************************");
				 System.out.println();
				 
				 
				 
				 if (opcaoAtualizar == 1) {//Analgesico
					Analgesico analgesico = new Analgesico();
				  	System.out.println("Id do rem�dio: ");
					int idAnalg = leitor.nextInt();
					leitor.nextLine();
					analgesico.setId(idAnalg);
					System.out.println("Nome do rem�dio: ");
					String nomeAnalg = leitor.nextLine();
					analgesico.setNome(nomeAnalg);
					System.out.println("Valor (centavos separar com virgula): ");
					Double valorAnalg = leitor.nextDouble();
					analgesico.setPreco(valorAnalg);
					daoAnalgesico.atualizar(analgesico);
					System.out.println();
					System.out.println("ATUALIZADO COM SUCESSO");
				 }
				  
				if (opcaoAtualizar == 2) {//Antiacido
					Antiacido antiacido = new Antiacido();
				  	System.out.println("Id do rem�dio: ");
					int idAntiac = leitor.nextInt();
					leitor.nextLine();
					antiacido.setId(idAntiac);
					System.out.println("Nome do rem�dio: ");
					String nomeAntiac = leitor.nextLine();
					antiacido.setNome(nomeAntiac);
					System.out.println("Valor (centavos separar com virgula): ");
					Double valorAntiac = leitor.nextDouble();
					antiacido.setPreco(valorAntiac);
					daoAntiacido.atualizar(antiacido);
					System.out.println();
					System.out.println("ATUALIZADO COM SUCESSO");
				}
					
				if (opcaoAtualizar == 3) {//Antibiotico
					Antibiotico antibiotico = new Antibiotico();
				  	System.out.println("Id do rem�dio: ");
					int idAntib = leitor.nextInt();
					leitor.nextLine();
					antibiotico.setId(idAntib);
					System.out.println("Nome do rem�dio: ");
					String nomeAntib = leitor.nextLine();
					antibiotico.setNome(nomeAntib);
					System.out.println("Valor (centavos separar com virgula): ");
					Double valorAntib = leitor.nextDouble();
					antibiotico.setPreco(valorAntib);
					daoAntibiotico.atualizar(antibiotico);
					System.out.println();
					System.out.println("ATUALIZADO COM SUCESSO");
				}
				
				System.out.println("****************************************************");
				System.out.println();
				System.out.println("DESEJA RETORNAR A MANUTEN��O DOS MEDICAMENTOS? ");
				System.out.println("DIGITE: 1-SIM OU 0-N�O ");
				contador = leitor.nextInt();
				leitor.nextLine();
				System.out.println("****************************************************");
			
			}
			
			if (opcaoAdm == 4) { //EXCUIR
				 System.out.println("DE QUAL GRUPO EXCUIR? ");
				 System.out.println("   1  -  Analgesico");
				 System.out.println("   2  -  Antiacido");
				 System.out.println("   3  -  Antibiotico");
				 int opcaoExcluir = leitor.nextInt();
				 leitor.nextLine();
				 System.out.println("****************************************************");
				 System.out.println();
				 
				 if (opcaoExcluir == 1) {//Analgesico
					 System.out.println("Id do rem�dio: ");
					 int idAnalg = leitor.nextInt();
					 leitor.nextLine();
					 daoAnalgesico.apagar(idAnalg);
					 System.out.println();
					 System.out.println("EXCLU�DO COM SUCESSO");
				 }
				 
				 if (opcaoExcluir == 2) {//Antiacido
					 System.out.println("Id do rem�dio: ");
					 int idAntiac = leitor.nextInt();
					 leitor.nextLine();
					 daoAntiacido.apagar(idAntiac);
					 System.out.println();
					 System.out.println("EXCLU�DO COM SUCESSO");
				 }
				 
				 if (opcaoExcluir == 3) {//Antibiotico
					 System.out.println("Id do rem�dio: ");
					 int idAntib = leitor.nextInt();
					 leitor.nextLine();
					 daoAntibiotico.apagar(idAntib);
					 System.out.println();
					 System.out.println("EXCLU�DO COM SUCESSO");
				 }
				
				 System.out.println("****************************************************");
					System.out.println();
					System.out.println("DESEJA RETORNAR A MANUTEN��O DOS MEDICAMENTOS? ");
					System.out.println("DIGITE: 1-SIM OU 0-N�O ");
					contador = leitor.nextInt();
					leitor.nextLine();
					System.out.println("****************************************************");
			}
			
		}
		
		System.out.println();
		System.out.println("******************* FIM DO PROGRAMA ****************");
		System.out.println();
		leitor.close();
		
	}

}
