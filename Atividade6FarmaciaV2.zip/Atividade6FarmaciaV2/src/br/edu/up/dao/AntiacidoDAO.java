package br.edu.up.dao;

import br.edu.up.model.Antiacido;

public class AntiacidoDAO extends GenericDAO<Antiacido> {

}
